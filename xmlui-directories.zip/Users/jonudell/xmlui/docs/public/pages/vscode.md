# XMLUI Tools for Visual Studio Code

- Syntax highlighting for .xmlui files and .xmlui.xs files
- Hover for core components
- Completion for core components
- Code formatting for .xmlui files
- Diagnostics for errors

Get the [VSIX](https://github.com/xmlui-org/xmlui/releases?q=vscode&expanded=true).


