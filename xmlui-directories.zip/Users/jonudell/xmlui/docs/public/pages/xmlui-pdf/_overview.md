## Xmlui Pdf Package

This package provides components for working with pdf files.

## Package Components

| Component | Description | Status |
| :---: | --- | :---: |
| [Pdf](./xmlui-pdf/Pdf) | The `Pdf` component provides a read-only preview of a pdf document's contents. | experimental |
