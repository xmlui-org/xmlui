# Legend [#legend]

>[!WARNING]
> This component is in an **experimental** state; you can use it in your app. However, we may modify it, and it may even have breaking changes in the future.Legend component to be displayed in a chart component.

## Properties

### `align (default: "center")`

The alignment of the legend

Available values: `left`, `right`, `center` **(default)**

### `verticalAlign (default: "bottom")`

The vertical alignment of the legend

Available values: `top`, `bottom` **(default)**, `middle`

## Events

This component does not have any events.

## Exposed Methods

This component does not expose any methods.

## Styling

This component does not have any styles.
