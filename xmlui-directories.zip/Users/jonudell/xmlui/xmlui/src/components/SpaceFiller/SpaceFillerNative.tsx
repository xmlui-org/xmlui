import styles from "./SpaceFiller.module.scss";

export const SpaceFiller = () => <div className={styles.spacer} />;
