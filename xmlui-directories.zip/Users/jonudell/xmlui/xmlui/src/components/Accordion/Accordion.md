# Accordion

%-PROP-START positionInGroup

The possible values are:

| Value    | Description                                                              |
| :------- | :----------------------------------------------------------------------- |
| `single` | The accordion stands alone (not in a group)                              |
| `first`  | This accordion is the first in a group                                   |
| `middle` | This accordion is between the first and last items in an accordion group |
| `last`   | This accordion is the last in a group                                    |

By default, this value is `single`.

%-PROP-END

%-PROP-START rotateExpanded

If this property has a value, only the collapsed icon is used. When the accordion is expanded, the collapsed icon is rotated with this angle.

%-PROP-END
