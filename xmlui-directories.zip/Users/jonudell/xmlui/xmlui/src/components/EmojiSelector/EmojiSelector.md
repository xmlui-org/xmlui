%-PROP-START autoFocus

```xmlui-pg copy display name="Example: autoFocus" height="420px"
<App>
  <EmojiSelector autoFocus="true" />
</App>
```

%-PROP-END

%-EVENT-START select

```xmlui-pg copy display name="Example: select" height="420px"
<App>
  <HStack var.selected="">
    <EmojiSelector onSelect="(emoji) => { selected = emoji }" />
    <Text value="Selected emoji: {selected}" />
  </HStack>
</App>
```

%-EVENT-END

